<?php get_header(); ?>

<div class="container">
    Perdu ?

    <a href="<?php echo home_url('/'); ?>">
        Page home
    </a>
</div>

<?php get_footer(); ?>